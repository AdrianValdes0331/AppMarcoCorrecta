//
//  WebServices.swift
//  Marco V1.4
//
//  Created by user191637 on 9/20/21.
//

import SwiftUI

import Foundation

enum AuthenticationError: Error{
    case invalidCredentials
    case custom(errorMessage: String)
}

struct LoginRequestBody: Codable{
    let username : String
    let password: String
}

struct LoginResponse: Codable{
    let token: String?
    let message: String?
    let success: Bool?
}

enum ComunicationError: Error{
    case connectionError
    case custom(errorMessage: String)
}

struct AddUserRequestBody: Codable{
    let username : String
    let password: String
    let usertype : String
}

struct AddUserResponse: Codable{
    let message: String?
    let success: Bool?
}

struct AddCitaRequestBody: Codable{
    let fecha : Date
    let usuario: String
    let turno : Int32
}

struct AddCitaResponse: Codable{
    let message: String?
    let success: Bool?
}

class Webservice{
    func login(username: String, password: String, completion: @escaping (Result<String, AuthenticationError>) -> Void) {
        
        guard let url = URL(string: "http://100.24.228.237:10023/users/login") else {
            completion(.failure(.custom(errorMessage: "URL is not Correct")))
            return
        }
    
        let body = LoginRequestBody(username: username, password: password)
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(body)
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard let data = data, error == nil else {
                completion(.failure(.custom(errorMessage: "No data")))
                return
            }
            
            guard let loginResponse = try? JSONDecoder().decode(LoginResponse.self, from: data) else {
                completion(.failure(.invalidCredentials))
                return
            }
            
            guard let token = loginResponse.token else {
                completion(.failure(.invalidCredentials))
                return
            }
            
            completion(.success(token))
            
            
        }.resume()
    }

    func signup(username: String, password: String, completion: @escaping (Result<Bool, ComunicationError>) -> Void) {
        
        guard let url = URL(string: "http://100.24.228.237:10023/users/addUser") else {
            completion(.failure(.custom(errorMessage: "URL is not Correct")))
            return
        }
    
        let body = AddUserRequestBody(username: username, password: password, usertype: "usuario")
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(body)
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard let data = data, error == nil else {
                completion(.failure(.custom(errorMessage: "No data")))
                return
            }
            
            guard let AddUserResponse = try? JSONDecoder().decode(AddUserResponse.self, from: data) else {
                completion(.failure(.connectionError))
                return
            }
            
            guard let token = AddUserResponse.success else {
                completion(.failure(.connectionError))
                return
            }
            
            completion(.success(token))
            
            
        }.resume()
    }

    
    func getUsers(completion: @escaping (Result<UserResponse, ComunicationError>) -> Void) {
        
        guard let url = URL(string: "http://100.24.228.237:10023/users/") else {
            completion(.failure(.custom(errorMessage: "URL is not Correct")))
            return
        }
    
        URLSession.shared.dataTask(with: url) { data, response, error in
            print(data!.count)
            let usersResponse = try! JSONDecoder().decode(UserResponse.self, from: data!)
            print(usersResponse)
            DispatchQueue.main.async {
                completion(.success(usersResponse))
            }
        }.resume()
            
            
    }
    
    func getExposiciones(completion: @escaping (Result<ExposicionesResponse, ComunicationError>) -> Void) {
        
        guard let url = URL(string: "http://100.24.228.237:10023/exposiciones") else {
            completion(.failure(.custom(errorMessage: "URL is not Correct")))
            return
        }
    
        URLSession.shared.dataTask(with: url) { data, response, error in
            print(data!.count)
            let exposicionesResponse = try! JSONDecoder().decode(ExposicionesResponse.self, from: data!)
            print(exposicionesResponse)
            DispatchQueue.main.async {
                completion(.success(exposicionesResponse))
            }
        }.resume()
            
            
    }
    //Citas
    func getCitas(fecha: Date, usuario: String, turno: Int32, completion: @escaping (Result<Bool, ComunicationError>) -> Void)  {
        
        guard let url = URL(string: "http://100.24.228.237:10023/citas/add") else {
            completion(.failure(.custom(errorMessage: "URL is not Correct")))
            return
        }
    
        let body = AddCitaRequestBody(fecha: fecha, usuario: usuario, turno: turno)
        
        //Codigo para formatear la fecha antes de enviarla a la API
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .formatted(formatter)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? encoder.encode(body)  // con esta linea de código puedes enviar la fecha formateada
        //request.httpBody = try? JSONEncoder().encode(body)
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard let data = data, error == nil else {
                completion(.failure(.custom(errorMessage: "No data")))
                return
            }
            
            guard let AddCitaResponse = try? JSONDecoder().decode(AddCitaResponse.self, from: data) else {
                completion(.failure(.connectionError))
                return
            }
            
            guard let token = AddCitaResponse.success else {
                completion(.failure(.connectionError))
                return
            }
            
            completion(.success(token))
            
            
        }.resume()
            
            
    }
}
