//
//  AccountView.swift
//  Marco V1.4
//
//  Created by user191637 on 9/30/21.
//

import SwiftUI

struct AccountView: View {
    
    @Binding var nombre: String
    
    @EnvironmentObject var loginVM : LoginViewModel
    
    
    var body: some View {
        
        ZStack {
            Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            GeometryReader { proxy in
                ScrollView {
                    VStack{
                        
                        HStack {
                            Image("imagen marco-1")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 60)
                            
                            Text("¡Vuelve Pronto!").font(.system(size: (30), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                            
                        }.padding(.horizontal)
                        .padding(.top)
                        
                        /*Image("UserDefault")
                        .resizable()
                        .background(Color(.cyan))
                        .scaledToFill()
                        .frame(width: 80, height: 80)
                        .clipShape(Circle())*/
                        
                        HStack{
                            TextField("nombre", text: $loginVM.username)
                        }.frame(height: 60)
                        .padding(.horizontal, 25)
                        .background(Color.white)
                        .cornerRadius(8.0)
                        .padding(.horizontal, 25)
                        .padding()
                        
                        HStack{
                            VStack {
                                Text("Favoritos").font(.system(size: (20), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                                NavigationLink(
                                    destination: FavoritosView(),
                                    label: {
                                        Image("star")
                                            .resizable()
                                            .scaledToFill()
                                            .background(Color("ColorClaro"))
                                            .background(Color.white)
                                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                            .frame(width: proxy.size.width / 10, height: proxy.size.height / 10)
                                            .padding(.horizontal, proxy.size.width / 5)
                                })
                            }
                            VStack {
                                Text("Encuentranos").font(.system(size: (20), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                                Link(destination: URL(string: "https://www.google.com.mx/maps/place/Museo+de+Arte+Contempor%C3%A1neo+de+Monterrey/@25.6647396,-100.3119801,17z/data=!3m1!4b1!4m5!3m4!1s0x8662be2e03fe39fd:0xbb7e3b710c501bb4!8m2!3d25.6647348!4d-100.3097914?hl=es")!) {
                                        Image("Gmaps2")
                                            .resizable()
                                            .scaledToFill()
                                            .background(Color.white)
                                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                            .frame(width: proxy.size.width / 10, height: proxy.size.height / 10)
                                            .padding(.horizontal, proxy.size.width / 5)
                                }
                            }
                            
                        }
                        
                        Button(action: {
                            loginVM.logout()
                                
                        }, label: {
                            Text("Salir")
                                .foregroundColor(.white)
                                .frame(width: 100, height: 40, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                                .background(Color("ColorMarco"))
                                .cornerRadius(15)
                        })
                            
                    }
                    .navigationBarTitle("Cuenta")
                    .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }
}

struct AccountView_Previews: PreviewProvider {
    static var previews: some View {
        AccountView(nombre: .constant("Usuario"))//Cambiar a user
    }
}


