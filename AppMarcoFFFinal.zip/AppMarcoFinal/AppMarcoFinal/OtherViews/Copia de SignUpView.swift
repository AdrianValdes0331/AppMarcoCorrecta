//
//  SignUpView.swift
//  Marco V1.4
//
//  Created by user191637 on 9/29/21.
//

import SwiftUI

struct SignUpView: View {
    
    @State var username : String = ""
    @State var password : String = ""
    
    @State private var showingAlert = false
    
    @EnvironmentObject var loginVM : LoginViewModel
    
    
    var body: some View {
        
        
        ZStack {
            Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack{
                
                VStack{
                    
                    HStack {
                        Image("imagen marco-1")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 60)
                        
                        Text("¡Crea tu cuenta Marco!").font(.system(size: (30), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                        
                    }.padding(.horizontal)
                    .padding(.top)
                    
                }
                HStack{
                    Image(systemName: "envelope")
                        .foregroundColor(.gray)
                    TextField("Email", text: $username)
                }.frame(height: 60)
                .padding(.horizontal, 20)
                .background(Color.white)
                .cornerRadius(8.0)
                .padding(.horizontal, 15)
                
                HStack{
                    Image(systemName: "lock")
                        .foregroundColor(.gray)
                        SecureInputView("Password", text: $password)
                }.frame(height: 60)
                .padding(.horizontal, 20)
                .background(Color.white)
                .cornerRadius(8.0)
                .padding(.horizontal, 15)
                
                //TextField("username", text: $username)
                //SecureField("password", text: $password)
                
                Button(action: {
                    loginVM.signup(username: username, password: password)
                    showingAlert.toggle()
                    
                }, label: {
                    Text("Sign Up")
                })
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("Cuenta Creada"), message: Text("Tu cuenta de Marco ha sido creada con éxito"), primaryButton: .default(Text("Entendido")), secondaryButton: .default(Text("Salir")))
                }
                
                
                
            }
        }
    }
}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}
