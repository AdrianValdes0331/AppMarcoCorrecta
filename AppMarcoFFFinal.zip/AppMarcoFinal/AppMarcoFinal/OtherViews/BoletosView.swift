//
//  BoletosView.swift
//  Marco V1.0
//
//  Created by user191637 on 9/3/21.
//

import SwiftUI

struct BoletosView: View {
    @State private var cita = Date()

    var body: some View {
    
        ZStack {
            Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            ScrollView{
                DatePicker(" Fecha Asignada", selection: $cita, in: Date()..., displayedComponents: .date).padding(.horizontal)
                singleCard(titulo: "Principiante", disponibilidad: 5, colorTicket: .green, contentText: ["Entrada a la sala principal", "Duracion todo el dia", "acceso a la app premium"])
                singleCard(titulo: "Regular", disponibilidad: 13, colorTicket: .blue, contentText: ["Entrada a la sala principal", "Duracion todo el dia", "acceso a la app premium"])
                singleCard(titulo: "Premium", disponibilidad: 2, colorTicket: .red, contentText: ["Entrada a la sala principal", "Duracion todo el dia", "acceso a la app premium"])
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
        }
    }
}

struct BoletosView_Previews: PreviewProvider {
    static var previews: some View {
        BoletosView()
    }
}
