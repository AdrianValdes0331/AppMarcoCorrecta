//
//  ExpoDetailView.swift
//  Exposiciones
//
//  Created by user188817 on 9/6/21.
//

import SwiftUI
import SDWebImageSwiftUI

struct ExpoDetailView: View {
    //let exposiciones : Media
    var exposiciones : ExposicionesModel

    var body: some View {
        
        ZStack {
            Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            ScrollView {
                VStack {
                    Text(exposiciones.sName)
                        .font(.system(size: (25), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                        //.padding()
                        .foregroundColor(.purple)
                    Text("\(String(exposiciones.iYear))")
                        .multilineTextAlignment(.center)
                        .foregroundColor(.purple)
                    Text(exposiciones.sAutor)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.purple)
                    
                    TabView{
                        ForEach(exposiciones.arrImages, id:\.self){ image in
                            // Cambiar por liga URL de api
                            AnimatedImage(url: URL(string: "http://100.24.228.237:10023/images/exposiciones/" + image))
                            /*AnimatedImage(url: URL(string: "http://100.24.228.237:10023/images/peliculas/Raya1.jpeg"))*/
                                .resizable()
                                .cornerRadius(15.0)
                                .frame(height: 200)
                                .frame(width: 350)
                                .scaledToFill()
                        }
                    }
                    .tabViewStyle(PageTabViewStyle())
                    
                    AddToFavoritoView(filter: exposiciones)
                    
                    Text(exposiciones.sDescription)
                        .multilineTextAlignment(.center)
                        .padding()
                        .foregroundColor(.purple)
                    
                    Text("Video sobre la exposicion: ")
                        .multilineTextAlignment(.center)
                        .padding()
                        .foregroundColor(.purple)
                    
                    VideoWebView(url: exposiciones.sVideo)
                        .cornerRadius(15.0)
                        .frame(height: 200)
                        .frame(width: 350)
                        .scaledToFill()
                
                    
                    /*
                    VideoPlayerView(url: "https://bit.ly/swswift")
                        .frame(height: 300)
                    */
                } //VStack principal
                .padding()
            }
        }.navigationBarTitle("Detalle")
        .navigationBarTitleDisplayMode(.inline)    }
}

struct MovieDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ExpoDetailView(exposiciones: ExposicionesModel.defaultMedia)
        //Media.defaultMedia)
    }
}
