//
//  HomeView.swift
//  Marco V1.0
//
//  Created by Elvia Rosas on 06/09/21.
//

import SwiftUI
import SDWebImageSwiftUI

struct HomeView: View {
    private var numberOfImages = 3;
    var body: some View {
        ZStack {
            Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            GeometryReader {proxy in
                ScrollView {
                    VStack{
                            
                            HStack {
                                Image("imagen marco-1")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 60)
                                
                                Text("¡El Museo de Todos!").font(.system(size: (30), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                                
                            }.padding(.horizontal)
                            .padding(.top)
                            
                            
                        HStack {
                            Link(destination: URL(string: "https://twitter.com/museomarco?lang=en")!) {
                                Image("Twitter")
                                .resizable()
                                .scaledToFill()
                                .background(Color.white)
                                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                .frame(width: proxy.size.width / 10, height: proxy.size.height / 10)
                            }
                            
                            Link(destination: URL(string: "https://www.facebook.com/museomarcomty/")!) {
                                Image("facebook")
                                .resizable()
                                .scaledToFill()
                                .background(Color.white)
                                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                .frame(width: proxy.size.width / 10, height: proxy.size.height / 10)
                                    .padding(.horizontal, proxy.size.width / 5)
                            }
                            
                            Link(destination: URL(string: "https://www.instagram.com/museomarco/?hl=en")!) {
                                Image("instagram")
                                .resizable()
                                .scaledToFill()
                                .background(Color.white)
                                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                .frame(width: proxy.size.width / 10, height: proxy.size.height / 10)
                            }
                                
                        }.padding(.bottom)
                            Text("Novedades").font(.system(size: (25), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                            
                            
                            TabView{
                                ForEach(0..<numberOfImages){ num in
                                    Image("\(num)")
                                        .resizable()
                                        .scaledToFit()
                                        .cornerRadius(25)
                                        .padding(.horizontal)
                                        .tag(num)
                                }
                            }.tabViewStyle(PageTabViewStyle())
                            .frame(width: proxy.size.width, height: proxy.size.height / 3)
                            
                            
                            Text("Recorrido Virtual").font(.system(size: (25), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                                    
                            Link(destination: URL(string: "https://www.museomarco.360s.mx/")!){
                                Image("Menu 3")
                                    .resizable()
                                    .scaledToFit()
                                    .cornerRadius(25)
                                    .padding(.horizontal)
                                    .frame(width: proxy.size.width, height: proxy.size.height / 3)
                                    .padding(.bottom)
                            }
                        
                            Text("Restaurante").font(.system(size: (25), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                        
                       
                            NavigationLink(
                                destination: RestaurantView(),
                                label: {
                                    Image("MenuMarco")
                                        .resizable()
                                        .scaledToFit()
                                        .cornerRadius(25)
                                        .padding(.horizontal)
                                        .frame(width: proxy.size.width, height: proxy.size.height / 5)
                                        .padding(.bottom)
                            })
                        
                                
                    }
                }
            }
        }//Abajo de Stack Principal
        //Zstack empalma
        .navigationBarBackButtonHidden(true)
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarTitle("Menu")
        //.navigationBarHidden(true)
    }
    
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}


