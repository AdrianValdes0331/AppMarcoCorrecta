//
//  ExposicionesView.swift
//  Marco V1.0
//
//  Created by user191637 on 9/3/21.
//

import SwiftUI

struct ExposicionesView: View {
    @EnvironmentObject private var media : MediaModel
    var body: some View {
        ZStack {
            //Image("MarcoColor").resizable().edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            ScrollView(.vertical, showsIndicators: false){
                VStack{
                    ForEach(media.arrExpos){expos in
                        NavigationLink(
                            destination: ExpoDetailView(exposiciones: expos),
                            label: {
                                ExpoRowView(exposiciones: expos)
                            })// Navigation Link
                        
                    }
                }
            } // ScrollView
            
        }
        .navigationBarTitle("Exposiciones")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(content: {
            ToolbarItem(placement: .principal, content: {
                HStack{
                    Image("LaunchScreenImage")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 20)
                    Text("Exposiciones")
                        .foregroundColor(.white)
                }
            })
        })
    }
}

struct ExposicionesView_Previews: PreviewProvider {
    static var previews: some View {
        ExposicionesView()
    }
}
