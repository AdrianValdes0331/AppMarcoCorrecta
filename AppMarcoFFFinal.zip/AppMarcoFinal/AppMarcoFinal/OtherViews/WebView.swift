//
//  WebView.swift
//  Exposiciones
//
//  Created by user188817 on 9/7/21.
//

import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {

    let html: String

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }


    func updateUIView(_ uiView: WKWebView, context: Context) {
        uiView.load(URLRequest(url: URL(string: html)!))
        uiView.allowsBackForwardNavigationGestures = false
    }
}
