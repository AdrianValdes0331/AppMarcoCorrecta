//
//  CitasView.swift
//  Marco V1.0
//
//  Created by user191637 on 9/3/21.
//

import SwiftUI

struct CitasView: View {
    @State var fecha: Date = Date()
    @State var persona: Int = 1
    @State var usuario: String = ""
    @State var email: String = ""
    @State var turno: String = ""
    let options = ["10:00am", "10:30am", "11:00am", "11:30am", "12:00pm", "12:30pm", "1:00pm", "1:30pm", "2:00pm", "2:30pm", "3:00pm", "3:30pm", "4:00pm", "4:30pm", "5:00pm", "5:30pm"]
    @EnvironmentObject var citasVM : CitasViewModel
    @State private var showingAlert = false
    init(){
        UITableView.appearance().backgroundColor = .clear
    }
    var body: some View {
        
        GeometryReader {proxy in
            ZStack{
                Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                
                ScrollView {
                    VStack{
                        HStack {
                            Image("imagen marco-1")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 60)
                            
                            Text("Tu visita a Marco").font(.system(size: (30), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                            
                        }.padding(.horizontal)
                        .padding(.top)
                        
                        Form(){
                            DatePicker("Fecha de Visita", selection: $fecha, in: Date()..., displayedComponents: .date).listRowBackground(Color(.clear))
                            
                            Picker("Turno", selection: $turno) {
                                ForEach(options, id: \.self) {
                                    Text($0)
                                }
                            }
                            
                            Stepper(value: $persona, in: 1...10){
                                Text("\(persona) Persona\(persona > 1 ? "s" : "")")
                            }.listRowBackground(Color(.clear))
                            
                            TextField("Nombre Completo", text: $usuario).listRowBackground(Color(.clear))
    
                            TextField("Email", text: $email).listRowBackground(Color(.clear))
                            
                            
                        }
                        .cornerRadius(25)
                        .frame(width: proxy.size.width/1.11, height: proxy.size.height/2.5)
                        .background(Color(.clear))
                        .scaledToFill()
                        
                        Button(action: {
                            citasVM.getCitas(fecha: fecha, usuario: usuario, turno: Int32(persona))
                            showingAlert.toggle()
                        }, label: {
                            Text("Agenda tu cita")
                        })
                        .foregroundColor(.white)
                        .font(.system(size: 18, weight:.medium))
                        .frame(width: proxy.size.width/3, height: proxy.size.height/15)
                        //.frame(maxWidth: .infinity)
                        .background(Color("ColorMarco"))
                        .cornerRadius(15)
                        .alert(isPresented: $showingAlert) {
                            Alert(title: Text("Cita Agendada"), message: Text("Tu cita en Marco ha sido agendada con éxito"), primaryButton: .default(Text("Entendido")), secondaryButton: .default(Text("Salir")))
                        }
                    }
                }
            
            
            }.navigationBarTitle("Citas")
            .navigationBarTitleDisplayMode(.inline)
        }
        .navigationBarTitle("Citas")
        
    }
}


struct CitasView_Previews: PreviewProvider {
    static var previews: some View {
        CitasView()
    }
}
