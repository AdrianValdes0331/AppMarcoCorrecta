//
//  MenuView.swift
//  Marco V1.0
//
//  Created by user191637 on 9/3/21.
//


import SwiftUI

struct MenuView: View {
    enum Tab {
        case home
        case movies
        case books
        case music
        case account
    }
    
    @State private var selection: Tab = .home
    @State var nombre: String = ""
    
    init(){
        
        let tabBarAppearance = UITabBarAppearance()
        tabBarAppearance.backgroundColor = UIColor(Color("ColorMarco"))
        UITabBar.appearance().standardAppearance = tabBarAppearance
        
    }
    
    var body: some View {
 
            VStack{
            
                TabView(selection: $selection){
                    NavigationView{
                        HomeView()
                    }
                    .tabItem{
                        let menuText = Text("Home", comment: "Home")
                        Label{
                            menuText
                        } icon: {
                            Image(systemName: "house")
                        }
                    }
                    .tag(Tab.home)
                    
                    NavigationView{
                        ExposicionesView()
                    }
                        .tabItem{
                            let menuText = Text("Exposiciones", comment: "Exposiciones")
                            Label{
                                menuText
                            } icon: {
                                Image(systemName: "film")
                            }
                        }
                        .tag(Tab.movies)
                    
                    NavigationView{
                        CitasView()
                    }
                        .tabItem{
                            let menuText = Text("Citas", comment: "Citas")
                            Label{
                                menuText
                            } icon: {
                                Image(systemName: "wallet.pass")
                            }
                        }
                        .tag(Tab.music)
                    
                    /*NavigationView{
                        RestaurantView()
                    }
                        .tabItem{
                            let menuText = Text("Restaurante", comment: "Restaurante")
                            Label{
                                menuText
                            } icon: {
                                Image(systemName: "person.crop.circle")
                            }
                        }
                        .tag(Tab.account)*/
                    
                    /*NavigationView{
                        FavoritosView()
                    }
                        .tabItem{
                            let menuText = Text("Favoritos", comment: "Favoritos")
                            Label{
                                menuText
                            } icon: {
                                Image(systemName: "star.fill")
                            }
                        }
                        .tag(Tab.account)*/
                    
                    NavigationView{
                        //Text("Account")
                        AccountView(nombre: $nombre)
                    }
                        .tabItem{
                            let menuText = Text("Cuenta", comment: "Cuenta")
                            Label{
                                menuText
                            } icon: {
                                Image(systemName: "person.crop.circle")
                            }
                        }
                        .tag(Tab.account)
                }
                .accentColor(Color(.white))
                
                
                
        }//VStack
        //.navigationBarHidden(true)
        //.navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .edgesIgnoringSafeArea(.all)
    }
}

struct MenuView_Previews: PreviewProvider {
    static var previews: some View {
        MenuView()
    }
}

