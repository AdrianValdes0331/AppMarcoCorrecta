//
//  ExpoRowView.swift
//  Exposiciones
//
//  Created by user188817 on 9/7/21.
//

import SwiftUI
import SDWebImageSwiftUI

struct ExpoRowView: View {
    //let exposiciones : Media
    var exposiciones : ExposicionesModel
    var body: some View {
            ZStack {
                Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                VStack{
                    
                    HStack {
                        Image("imagen marco-1")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 40)
                        
                        Text(exposiciones.sName).font(.system(size: (20), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                        
                    }.padding(.horizontal)
                    
                    /*Image(exposiciones.arrImages[0])
                    /*AnimatedImage(url: URL(string: "http://100.24.228.237:10023/images/peliculas/Raya1.jpeg"))*/
                        .resizable()
                        .cornerRadius(/*@START_MENU_TOKEN@*/3.0/*@END_MENU_TOKEN@*/)
                        .frame(height: 200)
                        .frame(width: 250)
                        .scaledToFill()*/
                    
                    ForEach(exposiciones.arrImages, id:\.self){ image in
                        // Cambiar por liga URL de api
                        AnimatedImage(url: URL(string: "http://100.24.228.237:10023/images/exposiciones/" + image))
                            .resizable()
                            .cornerRadius(15.0)
                            .frame(height: 200)
                            .frame(width: 350)
                            .scaledToFill()
                    }
                    
                    //VStack(alignment: .leading, spacing: 10){
                    Text("\(String(exposiciones.iYear))")
                        .font(.system(size: 18.0))
                        .foregroundColor(.purple)
                    Text(exposiciones.sAutor)
                        .font(.system(size: 18.0))
                        .foregroundColor(.purple)
                    //}
                    //Spacer()
                }
                .padding()
                Divider()
            }
        
        
    }
}

struct ExpoRowView_Previews: PreviewProvider {
    static var previews: some View {
        ExpoRowView(exposiciones: ExposicionesModel.defaultMedia)
        //Media.defaultMedia)
    }
}

/*HStack {
    Image("imagen marco-1")
    .resizable()
    .scaledToFit()
    .frame(height: 60)
    
    Text("¡El Museo de Todos!").font(.system(size: (30), weight: .semibold)).foregroundColor(Color("ColorMarco"))
    
}.padding(.horizontal)
.padding(.top)*/
