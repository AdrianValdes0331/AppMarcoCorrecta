//
//  RestaurantView.swift
//  Marco V1.0
//
//  Created by user191637 on 9/3/21.
//

import SwiftUI

struct RestaurantView: View {
    //@EnvironmentObject private var media : MediaModel
    
    var body: some View {
        ZStack {
            Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)            //Image("MarcoColor").resizable().edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            ScrollView(.vertical, showsIndicators: false){
                VStack{
                    
                    HStack {
                        Image("imagen marco-1")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 60)
                        
                        Text("¡Explora Nuevos Sabores!").font(.system(size: (25), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                        
                    }.padding(.horizontal)
                    .padding(.top)
                    
                    Image("RestaurantBanner1")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                    
                    Text("MARCO te ofrece un inigualable menú de alta cocina mexicana contemporánea diseñado por el Chef del Museo que consta de una deliciosa y variada barra de ensaladas, barra caliente con sopa o crema del día, distintos platos fuertes con opciones de cielo, mar y tierra, guarniciones y la mejor barra de postres de la casa; siempre diferentes para satisfacer a todos los paladares.\n¡Somos la mejor opción en el centro de la ciudad!")
                        .font(.system(size: (12), weight: .light))
                        .multilineTextAlignment(.center)
                        .padding()
                    
                    
                   /* HStack{
                        Image("imagen marco-1")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 180)
                        
                        VStack{
                            Image("imagen marco-1")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 90)
                            
                            Image("imagen marco-1")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 90)
                        }
                        .frame(height: 180)
                    }
                    .padding()*/
                    
                    Image("RestaurantImage")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 180)
                    .padding()
                    
                    HStack{
                        VStack{
                            Text("MENÚ MEXICANO CONTEMPORÁNEO")
                                .font(.system(size: (10), weight: .semibold))
                            Text("Martes a domingo. \nDe 1:00 a 4:00 pm.")
                                .font(.system(size: (10), weight: .light))
                                .frame(width: 200,  alignment: .leading)
                        }
                        .frame(height: 75, alignment: .topLeading)
                        VStack{
                            Text("RESERVACIONES")
                                .font(.system(size: (10), weight: .semibold))
                                .frame(width: 180, alignment: .leading)
                            Text("T. +52 (81) 8262.4562, 63 y 64\neventos@marco.org.mx")
                                .font(.system(size: (10), weight: .light))
                                .frame(width: 180,  alignment: .leading)
                            Text("DIRECCIÓN")
                                .font(.system(size: (10), weight: .semibold))
                                .frame(width: 180, alignment: .leading)
                            Text("Zuazua y Jardón S/N, Centro.\nMonterrey, N.L., México. 64000")
                                .font(.system(size: (10), weight: .light))
                                .frame(width: 180,  alignment: .leading)
                        }
                        .frame(height: 75, alignment: .topLeading)
                    }
                    .padding()
                    
                    Image("RestaurantBanner2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250)
                    .padding()
                    
                    
                    VStack{
                        
                        Link(destination: URL(string: "https://www.marco.org.mx/wp-content/uploads/2021/07/menu-restaurante1.pdf")!) {
                            Text("MENU \nSEMANAL")
                                .padding()
                                .background(Color("ColorMarco"))
                                .foregroundColor(.white)
                                .font(.headline)
                        }
                        Link(destination: URL(string: "https://www.marco.org.mx/restaurante/")!) {
                            Text("RESERVA")
                                .padding()
                                .background(Color("ColorMarco"))
                                .foregroundColor(.white)
                                .font(.headline)
                        }
                        /*
                        Button("MENU SEMANAL"){
                            
                        }
                        .padding()
                        .background(Color("ColorMarco"))
                        .frame(width: 150)
                        
                        Button("MENU PASTELERIA"){
                            
                        }
                        .padding()
                        .background(Color("ColorMarco"))
                        .frame(width: 150)

                        
                        Button("RESERVA"){
                            
                        }
                        .padding()
                        .background(Color("ColorMarco"))
                        .frame(width: 150)*/

                        
                    }
                }
            } // ScrollView
            
            
            
        }
        .navigationBarTitle("Restaurant")
        .navigationBarTitleDisplayMode(.inline)
        //.navigationBarHidden(true)
        //.navigationBarBackButtonHidden(true)
        /*.toolbar(content: {
            ToolbarItem(placement: .principal, content: {
                HStack{
                    Image("LaunchScreenImage")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 20)
                    Text("Restaurante")
                        .foregroundColor(.white)
                }
            })
        })*/
    }
}

struct RestaurantView_Previews: PreviewProvider {
    static var previews: some View {
        RestaurantView()
    }
}
