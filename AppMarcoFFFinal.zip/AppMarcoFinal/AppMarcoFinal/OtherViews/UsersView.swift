//
//  UsersView.swift
//  Marco V1.4
//
//  Created by user191637 on 9/29/21.
//

import SwiftUI

struct UsersView: View {
    
    @EnvironmentObject var usersVM : UsersViewModel
    
    var body: some View {
        
        VStack{
            List{
                ForEach(usersVM.users) { user in
                    
                    HStack{
                        Text(user.username)
                        Text(user.password)
                        Text(user.usertype[0])
                    }
                    
                }
            }
        }
        
    }
}

struct UsersView_Previews: PreviewProvider {
    static var previews: some View {
        UsersView()
    }
}
