//
//  LoginView.swift
//  Marco V1.0
//
//  Created by Alumno on 26/08/21.
//

import SwiftUI

struct SecureInputView: View {
    
    @Binding private var text: String
    @State private var isSecured: Bool = true
    private var title: String
    
    init(_ title: String, text: Binding<String>) {
        self.title = title
        self._text = text
    }
    
    var body: some View {
        ZStack(alignment: .trailing) {
            if isSecured {
                SecureField(title, text: $text)
            } else {
                TextField(title, text: $text)
            }
            Button(action: {
                isSecured.toggle()
            }) {
                Image(systemName: self.isSecured ? "eye.slash" : "eye")
                    .accentColor(.gray)
            }
        }
    }
}

struct LoginView: View {
    @EnvironmentObject private var loginVM : LoginViewModel
    @State var showSignUp : Bool = false
    
    init(){
        let navBarApperance = UINavigationBarAppearance()
        navBarApperance.titleTextAttributes = [.foregroundColor: UIColor.systemBackground]
        navBarApperance.largeTitleTextAttributes = [.foregroundColor: UIColor.systemBackground]
        navBarApperance.backgroundColor = UIColor(Color("ColorMarco"))
        navBarApperance.shadowColor = .clear
        UINavigationBar.appearance().standardAppearance = navBarApperance
        UINavigationBar.appearance().compactAppearance = navBarApperance
        UINavigationBar.appearance().scrollEdgeAppearance = navBarApperance
        UINavigationBar.appearance().tintColor = UIColor.systemPink
    }
    
    var body: some View {
        NavigationView{
            VStack{
                Spacer()
                VStack(spacing: 15.0){
                    VStack{
                        Image("Marco, logo")
                        Text("¡La App de Todos!").font(.system(size: (30), weight: .semibold)).foregroundColor(.white)
                    }
                    
                    HStack{
                        Image(systemName: "envelope")
                            .foregroundColor(.gray)
                        TextField("Email", text: $loginVM.username)
                    }.frame(height: 60)
                    .padding(.horizontal, 20)
                    .background(Color.white)
                    .cornerRadius(8.0)
                    .padding(.horizontal, 15)
                    
                    HStack{
                        Image(systemName: "lock")
                            .foregroundColor(.gray)
                            SecureInputView("Password", text: $loginVM.password)
                    }.frame(height: 60)
                    .padding(.horizontal, 20)
                    .background(Color.white)
                    .cornerRadius(8.0)
                    .padding(.horizontal, 15)
                    
                    NavigationLink(destination: MenuView()){
                        VStack{
                            Button(action: {
                                
                                loginVM.login()
                                
                            }, label: {
                                Text("Login")
                            })
                            .foregroundColor(.white)
                            .font(.system(size: 24, weight:.medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 20)
                            .background(Color.yellow)
                            .cornerRadius(8.0)
                            .padding(.horizontal, 75)
                            
                            Button(action: {
                                showSignUp.toggle()
                                
                            }, label: {
                                Text("SignUP")
                            })
                            .sheet(isPresented: $showSignUp, content: {
                                SignUpView()
                            })
                        }
                    }
                }
                Spacer()
                
            }
            .navigationBarTitle("Principal", displayMode: .inline)
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
            .padding(0.0)
            .background(Image("MarcoColor")
             .resizable().aspectRatio(contentMode: .fill)).edgesIgnoringSafeArea(.all)

        }

    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
