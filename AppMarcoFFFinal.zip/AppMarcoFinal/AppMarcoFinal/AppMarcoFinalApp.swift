//
//  AppMarcoFinalApp.swift
//  AppMarcoFinal
//
//  Created by user191637 on 10/14/21.
//

import SwiftUI

@main
struct AppMarcoFinalApp: App {
    let persistenceController = PersistenceController.shared
    
    @StateObject var media = MediaModel()
    @StateObject var loginVM = LoginViewModel()
    @StateObject var usersVM = UsersViewModel()
    @StateObject var citasVM = CitasViewModel()
    
    var islogged = false
    
    var body: some Scene {
        WindowGroup {
            if (loginVM.isLoggedin) {
            
                MenuView()
                    .environmentObject(media)
                    .environmentObject(loginVM)
                    .environmentObject(usersVM)
                    .environmentObject(citasVM)
                    .environment(\.managedObjectContext, persistenceController.container.viewContext)
            }
            else {
                LoginView()
                    .environmentObject(loginVM)
                
            }
        }
    }
}
