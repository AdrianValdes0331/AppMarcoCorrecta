//
//  CitasModel.swift
//  AppMarcoFinal
//
//  Created by user191637 on 10/17/21.
//

import SwiftUI
import Foundation

struct CitasResponse : Codable {
    var citas : [CitasModel]
}

struct CitasModel : Codable, Identifiable{
    var id : String
    var fecha : Date
    var usuario : String
    var turno: Int32
    
    enum CodingKeys : String, CodingKey{
        case id = "_id"
        case fecha = "fecha"
        case usuario = "usuario"
        case turno = "turno"
    }
}
