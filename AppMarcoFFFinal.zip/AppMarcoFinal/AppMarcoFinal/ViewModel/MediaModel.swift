//
//  MediaModel.swift
//  Exposiciones
//
//  Created by user188817 on 9/6/21.
//

import SwiftUI
import SDWebImageSwiftUI
class MediaModel: ObservableObject {
    
    //@Published var arrExpos = [Media]()
    @Published var arrExpos = [ExposicionesModel]()
    
    init() {
        LoadInfo()//Cambiar datos a datos en api
        //getMovies() //get
    }
    
    /*func getMovies(){
        Webservice().getExposiciones() { result in
            switch result {
            case .success(let moviesResult):
                    print("Obtuvo los usuarios")
                self.exposiciones = ExposicionesResponse.Expo //
                    
            case .failure(let error):
                print(error)
            }
        }
    }*/
    
    func LoadInfo() {
        
        var media: ExposicionesModel
        
        media = ExposicionesModel(id: "1", sName: "Galería FF Projects", iYear: 2021, sAutor: "Eduardo López", sDescription: "A raíz de la fuerte crisis económica que enfrentan los museos a nivel internacional, y derivado de la necesidad de buscar nuevos posicionamientos de las producciones artísticas actuales, MARCO pensó en el patio de las esculturas como una posibilidad de generar nexos con la comunidad artística de Monterrey que se ha preocupado por buscar un lugar en el espacio institucional global. Por tal motivo, su directora Taiyana Pimentel en colaboración con los Miembros del Consejo Directivo, pensaron en este proyecto.", arrImages: ["Marco1.png"], sVideo: "https://www.youtube.com/watch?v=8R01fHF8R0k&ab_channel=MuseoMARCO")
        arrExpos.append(media)
        
        media = ExposicionesModel(id: "2", sName: "La Poetica del Regreso", iYear: 2021, sAutor: "Taiyana Pimentel", sDescription: "En esta muestra curada por Taiyana Pimentel, se establece un paralelismo entre las prácticas posconceptuales y de inmersión en la construcción histórica por la que se ha conocido a García Torres, con los inicios de sus estrategias estéticas en las ciudades de Monterrey y México; se analiza a través de obras tempranas, las connotaciones del sentido del espacio y del paisaje nacidos tempranamente en la ciudad que le acogió en su época de formación y que son conceptos que lo han acompañado en su práctica artística posterior. Con base en esta premisa, se podrán apreciar obras como la pintura Cerro de la Silla, 1998 y el video Open Letter to Dr. Atl, 2005, realizado en Guadalajara.", arrImages: ["Marco2.png"], sVideo: "https://youtu.be/swhrA3qoqx4")
        arrExpos.append(media)
        
        media = ExposicionesModel(id: "3", sName: "Celebrando 30 Años", iYear: 2021, sAutor: "Museo Marco", sDescription: "En el año de 1989 un grupo de empresarios, profesionales del arte, encabezados por Doña Márgara Garza Sada de Fernández y el Ing. Diego Sada, anunciaron el proyecto de lo que sería el museo más importante del Norte de México y uno de los más relevantes en todo el país.", arrImages: ["Marco3.png"], sVideo: "https://youtu.be/QH7Fqx2RBwU")
        arrExpos.append(media)

    }

}

