//
//  MovieViewModel.swift
//  Marco V1.4
//
//  Created by user191637 on 10/7/21.
//

import Foundation

/*class MoviesViewModel: ObservableObject{
    @Published var movies = [MovieModel]()
    
    init(){
        getMovies()
    }
    
    func getMovies(){
        Webservice().getMovies() { result in
            switch result {
            case .success(let MoviesResult):
                    print("Obtuvo los usuarios")
                self.movies = MoviesResult.movies
                    
            case .failure(let error):
                print(error)
            }
        }
    }
}*/
