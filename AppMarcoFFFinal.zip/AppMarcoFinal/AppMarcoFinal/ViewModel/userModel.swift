//
//  userModel.swift
//  Marco V1.4
//
//  Created by user191637 on 9/29/21.
//

import SwiftUI
import Foundation

struct UserResponse : Codable {
    var users : [UserModel]
}

struct UserModel : Codable, Identifiable{
    var id : String
    var username : String
    var password : String
    var usertype: [String]
    
    enum CodingKeys : String, CodingKey{
        case id = "_id"
        case username = "username"
        case password = "password"
        case usertype = "usertype"
    }
}

