//
//  UsersViewModel.swift
//  Marco V1.4
//
//  Created by user191637 on 9/29/21.
//

import SwiftUI
import Foundation

class UsersViewModel: ObservableObject{
    @Published var users = [UserModel]()
    
    init(){
        getUsers()
    }
    
    func getUsers(){
        Webservice().getUsers() { result in
            switch result {
            case .success(let usersResult):
                    print("Obtuvo los usuarios")
                self.users = usersResult.users
                    
            case .failure(let error):
                print(error)
            }
        }
    }
}

