//
//  MovieModel.swift
//  Marco V1.4
//
//  Created by user191637 on 10/7/21.
//

import Foundation
import SwiftUI

struct MovieResponse : Codable {
    var movies : [MovieModel]
}

struct MovieModel : Identifiable , Codable {
    var id : String
    var sName: String
    var iYear: Int
    var rated : String
    var sGenre: String
    var sDuration: String
    var sHeadline: String
    var sOverview: String
    var dScore: Double
    var arrImages: [String]
    var sLogo: String
    var sTrailer: String
    
    enum CodingKeys : String, CodingKey {
        case id = "_id"
        case sName
        case iYear
        case rated
        case sGenre
        case sDuration
        case sHeadline
        case sOverview
        case dScore
        case arrImages
        case sLogo
        case sTrailer
        
    }
}
