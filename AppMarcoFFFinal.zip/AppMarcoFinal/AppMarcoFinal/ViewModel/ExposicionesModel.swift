//
//  PeliculasModel.swift
//  Marco V1.4
//
//  Created by user191637 on 10/8/21.
//

import SwiftUI
import Foundation
import SDWebImageSwiftUI

struct ExposicionesResponse : Decodable, Encodable  {
    var Expo : [ExposicionesModel]
}

struct ExposicionesModel: Identifiable, Decodable, Encodable {
    
    var id: String
    var sName: String
    var iYear: Int
    var sAutor: String
    var sDescription: String
    var arrImages: [String]
    var sVideo: String
    
    enum CodingKeys: String, CodingKey{
        case id = "_id"
        case sName 
        case iYear
        case sAutor
        case sDescription
        case arrImages
        case sVideo
    }
    
}
