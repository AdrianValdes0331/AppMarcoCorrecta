//
//  CitasViewModel.swift
//  AppMarcoFinal
//
//  Created by user191637 on 10/17/21.
//

import SwiftUI
import Foundation

class CitasViewModel : ObservableObject {
    
    var fecha : String = UserDefaults.standard.string(forKey: "fecha") ?? ""
    var usuario : String = UserDefaults.standard.string(forKey: "usuario") ?? ""
    var turno : String = UserDefaults.standard.string(forKey: "turno") ?? ""
    
    @Published var citas = [CitasModel]()
    
    /*init(){
        getCitas(fecha: Date, usuario: String, turno: Int32)
    }*/
    func getCitas(fecha: Date, usuario: String, turno: Int32){
        
        Webservice().getCitas(fecha: fecha, usuario: usuario, turno: turno) { result in
            
            switch (result) {
            case .success(let succ):
                print(succ)
                
                UserDefaults.standard.setValue(self.fecha, forKey: "fecha")
                UserDefaults.standard.setValue(self.usuario, forKey: "usuario")
                UserDefaults.standard.setValue(self.turno, forKey: "turno")
                
            case .failure(let error):
                print(error)
                    
            }
            
        }
        
    }
    
}
