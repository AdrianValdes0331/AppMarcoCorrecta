//
//  Default.swift
//  Exposiciones
//
//  Created by user188817 on 9/6/21.
//

import SwiftUI

extension Media{
    
    public static var defaultMedia = Media(id: "1", sName: "Pintura1", iYear: 2000, sAutor: "Juanchito Perez", sDescription: "Representa odio", arrImages: ["pintura","pintura2"], sVideo: "https://www.youtube.com/embed/aQFHKzN-yw0")
}

/*
 public static var defaultMedia = Media(sName: "Pintura1", iYear: 2000, sAutor: "Juanchito Perez", sDescription: "Representa odio", arrImages: ["pintura","pintura2"], sVideo: "https://www.youtube.com/embed/aQFHKzN-yw0")
 */
