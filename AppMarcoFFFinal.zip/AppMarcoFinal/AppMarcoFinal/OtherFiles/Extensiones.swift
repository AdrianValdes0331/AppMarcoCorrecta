//
//  Extensiones.swift
//  Marco V1.4
//
//  Created by user191637 on 10/13/21.
//

import Foundation
extension ExposicionesModel{
    public static var defaultMedia = ExposicionesModel (id: "1", sName: "Pintura1", iYear: 2000, sAutor: "Juanchito Perez", sDescription: "Representa odio", arrImages: ["pintura","pintura2"], sVideo: "https://www.youtube.com/embed/aQFHKzN-yw0")
}
