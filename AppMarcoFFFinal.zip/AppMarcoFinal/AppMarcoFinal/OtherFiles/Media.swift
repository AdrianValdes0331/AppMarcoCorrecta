//
//  Media.swift
//  Exposiciones
//
//  Created by user188817 on 9/6/21.
//

import SwiftUI

struct Media: Identifiable{
    
    var id: String
    var sName: String
    var iYear: Int
    var sAutor: String
    var sDescription: String
    var arrImages: [String]
    var sVideo: String
    
}
