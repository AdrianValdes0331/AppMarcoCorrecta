//
//  ExposicionFavorita+CoreDataProperties.swift
//  Marco V1.4
//
//  Created by user191637 on 10/11/21.
//
//

import Foundation
import CoreData


extension ExposicionFavorita {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ExposicionFavorita> {
        return NSFetchRequest<ExposicionFavorita>(entityName: "ExposicionFavorita")
    }

    @NSManaged public var id: String?
    @NSManaged public var sName: String?
    @NSManaged public var iYear: Int32
    @NSManaged public var sAutor: String?
    //@NSManaged public var sDescription: String?
    @NSManaged public var sVideo: String?
    @NSManaged public var arrImages: [String]?

}

extension ExposicionFavorita : Identifiable {
    
    var id_wrapped : String { id ?? " "} //si es nulo pon esto sino esto
    var sName_wrapped : String { sName ?? " "}
    var sAutor_wrapped : String { sAutor ?? " "}
    //var sDescription_wrapped : String { sDescription ?? " "}
    var sVideo_wrapped : String { sVideo ?? " "}
    var arrImages_wrapped : [String] { arrImages ?? ["logo.jpg"]}
}
