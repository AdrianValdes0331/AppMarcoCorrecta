//
//  singleCard.swift
//  asdfghjk
//
//  Created by user191530 on 9/7/21.
//

import SwiftUI

struct singleCard: View {
    let titulo: String
    let disponibilidad: Int
    let colorTicket: Color
    var contentText: [String]
    var body: some View {
        VStack {
            HStack {
                ZStack {
                    Image("MarcoColor")
                        .resizable()
                        .frame(width: 400, height: 70)
                        .cornerRadius(15)
                        .padding(.vertical, 20)
                    Text(titulo + " | " + String(disponibilidad) + " disponibles")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                }
            }
            VStack(alignment: .leading){
                ForEach(contentText, id:\.self) { text in
                    HStack {
                        Image(systemName: "ticket").foregroundColor(colorTicket)
                        Text(text)
                    }
                }
            }
            .padding(.horizontal, 10)
            ZStack {
                Text("Comprar")
                .foregroundColor(.white)
                    .font(.title2)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)
                .background(Color.yellow)
                .cornerRadius(15.0)
                .padding(.horizontal, 145)
            }

        }//ds
        .scaledToFit()
        
    }
}

struct singleCard_Previews: PreviewProvider {
    static var previews: some View {
        singleCard(titulo: "Early bird", disponibilidad: 5, colorTicket: .pink, contentText: ["Entrada a la sala principal", "Duracion todo el dia", "acceso a la app premium"])
    }
}
