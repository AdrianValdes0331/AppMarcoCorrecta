//
//  ExposicionFavorita+CoreDataClass.swift
//  Marco V1.4
//
//  Created by user191637 on 10/11/21.
//
//

import Foundation
import CoreData

@objc(ExposicionFavorita)
public class ExposicionFavorita: NSManagedObject {

}
