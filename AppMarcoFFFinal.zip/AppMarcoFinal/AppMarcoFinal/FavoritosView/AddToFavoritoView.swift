//
//  AddToFavoritoView.swift
//  Marco V1.4
//
//  Created by user191637 on 10/12/21.
//

import SwiftUI

struct AddToFavoritoView: View {
    
    @Environment(\.managedObjectContext) var viewContext
        
    var fetchRequest: FetchRequest<ExposicionFavorita>
    var favoritos: FetchedResults<ExposicionFavorita> {
        fetchRequest.wrappedValue
    }
    
    var exposiciones: ExposicionesModel
    
    var body: some View {
        VStack{
            if favoritos.count == 0 {
                Text("Agragar a Favoritos")
                Button(action: {
                    self.SaveExpoToFav(exposiciones: exposiciones)
                }, label: {
                    Image(systemName: "star")
                        .foregroundColor(.gray)
                        .font(.system(size: 24))
                })
            } else {
                Text("Quitar de favoritos")
                Button(action: {
                    self.DeleteExpoFromFav(exposiciones: exposiciones)
                }, label: {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                        .font(.system(size: 24))
                    
                })
            }
        }
    }
    
    init(filter: ExposicionesModel) {

        exposiciones = filter
        fetchRequest = FetchRequest<ExposicionFavorita>(entity: ExposicionFavorita.entity(), sortDescriptors: [],
            predicate: NSPredicate(format: "id == %@",   filter.id))
    }
    
    func SaveExpoToFav(exposiciones: ExposicionesModel) {

            let e = ExposicionFavorita(context: viewContext)
        
            e.id = exposiciones.id
            e.sName = exposiciones.sName
            e.iYear = Int32(exposiciones.iYear)
            e.sAutor = exposiciones.sAutor
            //e.sDescription = exposiciones.sDescription
            e.sVideo = exposiciones.sVideo
            var arrImages = [String]()
            for i in exposiciones.arrImages {
                arrImages.append(i)
            }
            e.arrImages = arrImages
            
            try? viewContext.save()

    }
    
    func DeleteExpoFromFav(exposiciones: ExposicionesModel) {
            
        if let index = favoritos.firstIndex(where: {$0.id == exposiciones.id}){
            viewContext.delete(favoritos[index])
            try? viewContext.save()
        }

    }
    
}

struct AddToFavoritoView_Previews: PreviewProvider {
    static var previews: some View {
        AddToFavoritoView(filter: ExposicionesModel.defaultMedia)
    }
}
