//
//  FavoritosRowView.swift
//  Marco V1.4
//
//  Created by user191637 on 10/12/21.
//

import SwiftUI
import SDWebImageSwiftUI

struct FavoritosRowView: View {
    //let exposiciones : Media
    let exposiciones : ExposicionFavorita
    var body: some View {
            ZStack {
                Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                VStack{
                    //Image(exposiciones.arrImages[0])
                    ForEach(exposiciones.arrImages_wrapped, id:\.self){ image in
                        // Cambiar por liga URL de api
                        Image(image)
                            .resizable()
                            .cornerRadius(15.0)
                            .frame(height: 200)
                            .frame(width: 350)
                            .scaledToFill()
                    }
                        
                    VStack(alignment: .leading, spacing: 10){
                        Text(exposiciones.sName_wrapped)
                            .font(.headline)
                            .foregroundColor(.purple)
                        Text("\(String(exposiciones.iYear))")
                            .font(.system(size: 18.0))
                            .foregroundColor(.purple)
                        Text(exposiciones.sAutor_wrapped)
                            .font(.system(size: 18.0))
                            .foregroundColor(.purple)
                    }
                    Spacer()
                }
                .padding()
                Divider()
            }
        
        
    }
}

struct FavoritosRowView_Previews: PreviewProvider {
    static var previews: some View {
        FavoritosRowView(exposiciones:ExposicionFavorita())
    }
}
