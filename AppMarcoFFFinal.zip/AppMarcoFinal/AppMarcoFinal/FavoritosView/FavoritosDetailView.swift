//
//  FavoritosDetailView.swift
//  Marco V1.4
//
//  Created by user191637 on 10/11/21.
//

import SwiftUI
import AVKit
import SDWebImageSwiftUI

struct FavoritosDetailView: View {
    let exposiciones : ExposicionFavorita
    var body: some View {
            
            ZStack {
                Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                ScrollView {
                    VStack {
                        
                        Text(exposiciones.sName_wrapped)
                            .font(.headline)
                            .padding()
                            .foregroundColor(.purple)
                        Text("\(String(exposiciones.iYear))")
                            .multilineTextAlignment(.center)
                            .foregroundColor(.purple)
                        Text(exposiciones.sAutor_wrapped)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.purple)
                        
                        TabView{
                            ForEach(exposiciones.arrImages_wrapped, id:\.self){ image in
                                Image(image)
                                    .resizable()
                                    .cornerRadius(25)
                                    .scaledToFit()
                                    .frame(height: 200)
                                    .clipShape(Rectangle())
                            }
                        }
                        .tabViewStyle(PageTabViewStyle())
                        
                        /*Text(exposiciones.sDescription_wrapped)
                            .multilineTextAlignment(.center)
                            .padding()
                            .foregroundColor(.purple)*/
                        
                        
                        Text("Video sobre la exposicion: ")
                            .multilineTextAlignment(.center)
                            .padding()
                            .foregroundColor(.purple)
                        
                        VideoWebView(url: exposiciones.sVideo_wrapped)
                            .cornerRadius(15.0)
                            .frame(height: 200)
                            .frame(width: 350)
                            .scaledToFill()
                        
                    } //VStack principal
                    .padding()
                }
            }
        }
}

struct FavoritosDetailView_Previews: PreviewProvider {
    static var previews: some View {
        FavoritosDetailView(exposiciones : ExposicionFavorita())
    }
}
