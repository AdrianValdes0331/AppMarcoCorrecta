//
//  FavoritosView.swift
//  Marco V1.4
//
//  Created by user191637 on 10/11/21.
//

import SwiftUI

struct FavoritosView: View {
    
    @Environment(\.managedObjectContext) var viewContext
    @FetchRequest(entity: ExposicionFavorita.entity(),sortDescriptors: [NSSortDescriptor(key: "sName", ascending: true)])
    
    var favoritos: FetchedResults<ExposicionFavorita>
    //var exposiciones : ExposicionesModel
    var body: some View {
        ZStack {
            Color("ColorClaro").edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            ScrollView(.vertical, showsIndicators: false){
                VStack{
                    
                    HStack {
                        Image("imagen marco-1")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 60)
                        
                        Text("¡Explora lo que mas te gusto!").font(.system(size: (25), weight: .semibold)).foregroundColor(Color("ColorMarco"))
                        
                    }.padding(.horizontal)
                    .padding(.top)
                    
                    ForEach(favoritos){exposiciones in
                        NavigationLink(
                            destination: FavoritosDetailView(exposiciones: exposiciones),
                            label: {
                                ExpoFavoritosRowView(exposiciones: exposiciones)
                            })// Navigation Link
                    }
                }
            } // ScrollView
            
            
            
        }
        .navigationBarTitle("Favoritos")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct FavoritosView_Previews: PreviewProvider {
    static var previews: some View {
        FavoritosView ()
    }
}
